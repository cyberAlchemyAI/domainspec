domainspec-subagents-strategy bundle
Paths preserved relative to the domainspec repo root so SKILL.md links resolve.
Scope: SKILL.md + directly-linked dependencies (not transitive).
